#include <SDL2/SDL.h>
#include <SDL2/SDL_audio.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_mixer.h>

#include <stdio.h>
#include <pthread.h>
#include <time.h>

#include <vector>
#include <stdlib.h>
#include <bits/stdc++.h>

#include <cstring>
#include <climits>

#include <string>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <sstream>
#include <iostream>

